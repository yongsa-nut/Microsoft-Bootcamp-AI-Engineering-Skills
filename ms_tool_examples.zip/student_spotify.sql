CREATE TABLE artists (
    artist_id INTEGER PRIMARY KEY,
    name TEXT NOT NULL,
    country TEXT,
    genre TEXT
);

CREATE TABLE songs (
    song_id INTEGER PRIMARY KEY,
    title TEXT NOT NULL,
    artist_id INTEGER,
    release_year INTEGER,
    duration_sec INTEGER,
    streams_millions REAL,
    mood TEXT,
    FOREIGN KEY (artist_id) REFERENCES artists(artist_id)
);

INSERT INTO artists VALUES
(1, 'LISA', 'Thailand', 'K-Pop'),
(2, 'BTS', 'South Korea', 'K-Pop'),
(3, 'Taylor Swift', 'USA', 'Pop'),
(4, 'Billkin', 'Thailand', 'Pop'),
(5, 'Three Man Down', 'Thailand', 'Indie'),
(6, 'Tontrakul', 'Thailand', 'Indie'),
(7, 'Blackpink', 'South Korea', 'K-Pop'),
(8, 'Numcha', 'Thailand', 'R&B'),
(9, 'Ed Sheeran', 'UK', 'Pop'),
(10, 'Milli', 'Thailand', 'Hip-Hop'),
(11, 'Bodyslam', 'Thailand', 'Rock'),
(12, 'NewJeans', 'South Korea', 'K-Pop');

INSERT INTO songs VALUES
(1, 'ROCKSTAR', 1, 2024, 207, 820.5, 'hype'),
(2, 'Dynamite', 2, 2020, 199, 1800.0, 'happy'),
(3, 'Anti-Hero', 3, 2022, 200, 1500.3, 'chill'),
(4, 'อักษรย่อ', 4, 2023, 245, 180.2, 'sad'),
(5, 'ถ้าเธอรักฉันจริง', 5, 2022, 230, 250.0, 'sad'),
(6, 'ลาลาลัย', 6, 2023, 210, 120.7, 'chill'),
(7, 'How You Like That', 7, 2020, 181, 1200.0, 'hype'),
(8, 'พบกันใหม่', 8, 2023, 195, 95.3, 'chill'),
(9, 'Shape of You', 9, 2017, 234, 4000.1, 'happy'),
(10, 'Mirror Mirror', 10, 2021, 180, 85.0, 'hype'),
(11, 'คราม', 11, 2022, 270, 150.8, 'sad'),
(12, 'Ditto', 12, 2022, 185, 900.4, 'chill'),
(13, 'Butter', 2, 2021, 164, 1400.0, 'happy'),
(14, 'Cruel Summer', 3, 2023, 178, 1100.6, 'hype'),
(15, 'MONEY', 1, 2021, 169, 950.0, 'hype'),
(16, 'สุดท้ายก็หมา', 5, 2023, 220, 200.1, 'sad'),
(17, 'Photograph', 9, 2015, 258, 2800.0, 'sad'),
(18, 'OMG', 12, 2023, 212, 750.2, 'happy'),
(19, 'ยังคง', 11, 2019, 285, 130.0, 'sad'),
(20, 'Shutdown', 7, 2022, 186, 600.5, 'hype');
